# Vfunc

## Compilando:

primeiro, compile a base:
` make `

depois, permita que o arquivo ` configure ` seja rodado:
` chmod +x configure `

finalmente, termine a instalação rodando o arquivo:
` sudo ./configure `


### autor: João Pedro de Moura Vasconcelos
### licença: GPL 3.0
### versão: 1.0.0
